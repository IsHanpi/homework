#include<iostream>
using namespace std;
int k;//�������
int main()
{
	int i = k + 1;
	cout << i++ << endl;
	//ɾȥint i = 1;
	cout << i++ << endl;
	cout << "Welcome to C++" << endl;
	return 0;
}